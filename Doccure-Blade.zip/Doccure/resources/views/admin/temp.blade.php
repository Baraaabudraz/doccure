@extends('admin.parent')

@section('title','Dashboard')

@section('style')

@endsection

@section('page-wrapper')

@endsection

@section('scripts')

@endsection
